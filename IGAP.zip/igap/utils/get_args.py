import argparse

def get_args():
    parser = argparse.ArgumentParser()
    ##### model path settings
    parser.add_argument('--log_path', action='store', default='./logs', type=str)
    parser.add_argument('--data_path', action='store', default='./datasets', type=str)
    parser.add_argument('--ft_model_ckpt_path', action='store', default='./finetune_ckpt', type=str)
    
    ##### all training settings
    parser.add_argument('--use_cuda', action='store', default=True, type=bool)
    parser.add_argument('--seed', action='store', default=2021, type=int)

    ##### model settings
    # SAGE GCN GAT
    parser.add_argument('--gnn_type', action='store', default="SAGE", type=str)
    parser.add_argument('--gnn_layer_num', action='store', default=2, type=int)
    parser.add_argument('--gnn_hidden_dim', action='store', default=128, type=int)

    ##### pre-training settings
    parser.add_argument('--pt_dataset_name', action='store', default="Cora_ML", type=str)
    parser.add_argument('--pt_graph_split_num', action='store', default=200, type=int)
    parser.add_argument('--pt_type', action='store', default="GraphCL", type=str) #Graph_CL, DGI, Link_Pred, SimGRACE
    parser.add_argument('--pt_epochs', action='store', default=500, type=int)
    parser.add_argument('--pt_ckpt_epoch', action='store', default=50, type=int)
    parser.add_argument('--pt_lr', action='store', default=0.0001, type=float)
    parser.add_argument('--pt_weight_decay', action='store', default=1e-5, type=float)
    parser.add_argument('--pt_lr_strategy', action='store', default=None, type=str)
    parser.add_argument('--pt_opt_type', action='store', default="Adam", type=str)
    parser.add_argument('--pt_batch_size', action='store', default=10, type=int)
    parser.add_argument('--pt_aug1', action='store', default='dropN', type=str)  # 'dropN', 'permE', 'maskN'
    parser.add_argument('--pt_aug2', action='store', default='permE', type=str)  # 'dropN', 'permE', 'maskN'
    parser.add_argument('--pt_aug_ratio', action='store', default=0.1, type=float) 
    parser.add_argument('--pt_model_ckpt_path', action='store', default='./pretrain_ckpt', type=str)

    ##### finetune settings
    parser.add_argument('--ft_dataset_name', action='store', default="Cora", type=str)
    # inductive_graph_prompt, graph_fine_tune graph_prompt_augmentation graph_scratch
    parser.add_argument('--ft_type', action='store', default="graph_scratch", type=str) 
    parser.add_argument('--ft_epochs', action='store', default=50, type=int)
    parser.add_argument('--ft_lr', action='store', default=0.001, type=float)
    parser.add_argument('--ft_weight_decay', action='store', default=1e-5, type=float)
    parser.add_argument('--ft_opt_type', action='store', default="Adam", type=str)
    parser.add_argument('--ft_froze', action='store', default=False, type=bool)
    parser.add_argument('--ft_batch_size', action='store', default=40, type=int)
    parser.add_argument('--load_pt_ckpt', action='store', default=200, type=int)
    parser.add_argument('--ft_ckpt_epoch', action='store', default=20, type=int)

    ##### prompt settings
    parser.add_argument('--ft_aug_type_list', action='store', default=["Drop_node", "Mask_feature", "Delete_edge"], type=list)  # Node_mask, Edge_shift, Feature_mask
    parser.add_argument('--ft_aug_ratio_list', action='store', default=[0.05, 0.1, 0.15], type=list)
    parser.add_argument('--ft_aug_num', action='store', default=3, type=int)

    args = parser.parse_args()
    return args
