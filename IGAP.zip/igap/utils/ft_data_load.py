from torch_geometric.datasets import CitationFull
from torch_geometric.loader.cluster import ClusterData
from torch_geometric.utils import to_undirected
from torch_geometric.data import Data
import torch
import numpy as np
import os

def ft_data_loader(dataname='arxiv', num_parts=200):
    if dataname == "arxiv":
        load_ft_data_path = "./dataset/fine_tune_data/{}".format(dataname)

        features = torch.tensor(np.loadtxt(os.path.join(load_ft_data_path, 'features')), dtype=torch.float)
        edges = torch.tensor(np.loadtxt(os.path.join(load_ft_data_path, "edges")).transpose(), dtype=torch.long)
        labels = torch.tensor(np.loadtxt(os.path.join(load_ft_data_path, 'labels')), dtype=torch.long)
        ft_data = Data(x=features, edge_index=edges, y=labels)

        edge_index = ft_data.edge_index.detach()
        edge_index = to_undirected(edge_index)
        ft_data.edge_index = edge_index
        input_dim = ft_data.x.shape[1]
        num_class = len(set(list(np.array(ft_data.y))))

        nodes_list = list(range(len(ft_data.y)))
        train_test_split_stone = int(0.6*len(nodes_list))
        test_eval_split_stone = int(0.8*len(nodes_list))
        train_nids = nodes_list[:train_test_split_stone]
        test_nids = nodes_list[train_test_split_stone:test_eval_split_stone]
        eval_nids = nodes_list[test_eval_split_stone:]
        
        return ft_data, input_dim, train_nids, test_nids, eval_nids, num_class
    
    elif dataname == "Cora" or dataname == "Cora_ML":
        ft_dataset = CitationFull(root="./dataset/raw_data/{}".format(dataname), name=dataname)
        ft_data = ft_dataset[0].detach()
        edge_index = ft_data.edge_index.detach()
        edge_index = to_undirected(edge_index)
        ft_data.edge_index = edge_index
        input_dim = ft_data.x.shape[1]
        num_class = len(set(list(np.array(ft_data.y))))

        nodes_list = list(range(len(ft_data.y)))
        train_test_split_stone = int(0.6*len(nodes_list))
        test_eval_split_stone = int(0.8*len(nodes_list))
        train_nids = nodes_list[:train_test_split_stone]
        test_nids = nodes_list[train_test_split_stone:test_eval_split_stone]
        eval_nids = nodes_list[test_eval_split_stone:]

        return ft_data, input_dim, train_nids, test_nids, eval_nids, num_class


def ft_data_loader(dataname='Cora', num_parts=200):
    ft_dataset = CitationFull(root="./dataset/raw_data/{}".format(dataname), name=dataname)

    ft_data = ft_dataset[0].detach()
    edge_index = ft_data.edge_index.detach()
    edge_index = to_undirected(edge_index)
    ft_data.edge_index = edge_index
    input_dim = ft_data.x.shape[1]
    num_class = len(set(list(np.array(ft_data.y))))

    nodes_list = list(range(len(ft_data.y)))
    train_test_split_stone = int(0.6*len(nodes_list))
    test_eval_split_stone = int(0.8*len(nodes_list))
    train_nids = nodes_list[:train_test_split_stone]
    test_nids = nodes_list[train_test_split_stone:test_eval_split_stone]
    eval_nids = nodes_list[test_eval_split_stone:]
    # train_nids = ft_data.train_mask
    # test_nids = ft_data.test_mask
    # eval_nids = ft_data.eval_mask

    return ft_data, input_dim, train_nids, test_nids, eval_nids, num_class