from torch_geometric.datasets import CitationFull
from torch_geometric.loader import ClusterData, RandomNodeLoader
from torch_geometric.utils import to_undirected
from torch_geometric.data import Data

def pt_data_loader(dataname="Cora", num_parts=200):
    pt_dataset = CitationFull(root="./dataset/raw_data/{}".format(dataname), name=dataname)
    pt_data = pt_dataset[0]
    x = pt_data.x.detach()
    edge_index = pt_data.edge_index.detach()
    edge_index = to_undirected(edge_index)
    data = Data(x=x, edge_index=edge_index)
    input_dim = data.x.shape[1]
    graph_list = list(ClusterData(data=data, num_parts=num_parts, save_dir='./dataset/pretrain_data/{}/'.format(dataname)))

    return graph_list, input_dim