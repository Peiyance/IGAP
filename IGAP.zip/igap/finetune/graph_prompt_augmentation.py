import torch
import torch.optim as optim
from torch.autograd import Variable
from torch_geometric.loader import DataLoader, NodeLoader, NeighborLoader
from torch_geometric.sampler import NeighborSampler
from torch_geometric.data import Data
from random import shuffle
import random
import numpy as np
import torch.nn.functional as F
from collections import defaultdict

from models.sage import GraphSage
from models.gat import GAT
from models.gin import GIN
from models.gcn import GCN
from utils.graph_cl_utils import graph_views

class GraphPromptAugmentModel(torch.nn.Module):
    def __init__(self, gnn):
        super(GraphPromptAugmentModel, self).__init__()
        self.gnn = gnn
    
    def loss_c(self, center_embed, pos_embeds, neg_embeds, device=torch.device("cpu")):
        T = 0.1
        center_emb_abs = F.normalize(center_embed, dim=1)
        pos_embeds_abs = F.normalize(pos_embeds, dim=1)
        neg_embeds_abs = F.normalize(neg_embeds, dim=1)

        pos_target = torch.ones(pos_embeds_abs.size()[0],)
        neg_target = -1*torch.ones(pos_embeds_abs.size()[0],)

        target = torch.cat([pos_target, neg_target], dim=0)
        context_emb = torch.cat([pos_embeds_abs, neg_embeds_abs], dim=0)
        center_emb = center_emb_abs.expand(context_emb.size())
        margin = torch.tensor(0.2)
        if device == torch.device("cuda"):
            target = target.to(device)
            context_emb = context_emb.to(device)
            center_emb = center_emb.to(device)
            margin = margin.to(device)

        loss_f = torch.nn.CosineEmbeddingLoss(margin=margin, reduction="mean")

        loss = loss_f(center_emb, context_emb, target)
        return loss

    def forward(self, graph):
        return self.gnn(graph.x, graph.edge_index, graph_emb=True)

    def forward_context(self, batch_data, device=torch.device("cuda")):
        batch_emb = []
        for graph in batch_data:
            if device == torch.device("cuda"):
                graph.to(device)
            emb = self.gnn(graph.x, graph.edge_index, graph_emb=True)
            batch_emb.append(emb)
        batch_emb = torch.cat(batch_emb, dim=0)
        return batch_emb

    def forward_center(self, batch_data, aug_num, aug_ratio_list=[0.05, 0.1, 0.15], aug_type_list=["Drop_node", "Mask_feature", "Delete_edge"], device=torch.device("cpu")):
        # batch_emb = []
        # for data in batch_data:
        #     batch_emb.append(self.forward_prompt(data, aug_num, aug_ratio_list, aug_type_list))
        # return batch_emb
        return self.forward_prompt(batch_data, aug_num, aug_ratio_list, aug_type_list, device=device)

    def forward_prompt(self, data, aug_num, aug_ratio_list=[0.05, 0.1, 0.15], aug_type_list=["Drop_node", "Mask_feature", "Delete_edge"], device=torch.device("cpu")):
        aug_data_list = self.prompt_augment(data, aug_num, aug_ratio_list, aug_type_list)
        aug_prompt_emb_list = []
        if device == torch.device("cuda"):
            data.to(device)
        query_emb = self.gnn(data.x, data.edge_index, graph_emb=True)
        for aug_data in aug_data_list:
            if device == torch.device("cuda"):
                aug_data.to(device)
            aug_prompt_emb_list.append(self.gnn(aug_data.x, aug_data.edge_index, graph_emb=True))
        key_emb = torch.cat(aug_prompt_emb_list, dim=0)

        attn = torch.softmax(torch.mm(query_emb, key_emb.transpose(0,1)), dim=-1)
        emb = 0.8*query_emb + 0.2*torch.mm(attn, key_emb)

        return emb
    
    def prompt_augment(self, data, aug_num, aug_ratio_list=[0.05, 0.1, 0.15], aug_type_list=["Drop_node", "Mask_feature", "Delete_edge"]):
        prompt_aug_list = []
        for i in range(aug_num):
            aug_type = random.sample(aug_type_list, k=1)[0]
            aug_ratio = random.sample(aug_ratio_list, k=1)[0]
            if aug_type is "Drop_node":
                aug_data = self.drop_node(data, aug_ratio)
                prompt_aug_list.append(aug_data)
            elif aug_type is "Mask_feature":
                aug_data = self.mask_feature(data, aug_ratio)
                prompt_aug_list.append(aug_data)
            elif aug_type is "Delete_edge":
                aug_data = self.delete_edge(data, aug_ratio)
                prompt_aug_list.append(aug_data)
            else:
                print("Unknow augment type: {}".format(aug_type))
                pass
        return prompt_aug_list

    def mask_feature(self, data, aug_ratio):
        data.cpu()
        node_num, feat_dim = data.x.size()
        mask_num = int(node_num * aug_ratio)

        token = data.x.mean(dim=0)
        idx_mask = np.random.choice(node_num, mask_num, replace=False)
        data.x[idx_mask] = token.clone().detach()

        return data

    def drop_node(self, data, aug_ratio):
        data.cpu()
        node_num, _ = data.x.size()
        _, edge_num = data.edge_index.size()
        drop_num = int(node_num * aug_ratio)

        idx_perm = np.random.permutation(node_num)

        idx_drop = idx_perm[:drop_num]
        idx_nondrop = idx_perm[drop_num:]
        idx_nondrop.sort()
        idx_dict = {idx_nondrop[n]: n for n in list(range(idx_nondrop.shape[0]))}

        edge_index = data.edge_index.numpy()

        edge_index = [[idx_dict[edge_index[0, n]], idx_dict[edge_index[1, n]]] for n in range(edge_num) if
                    (not edge_index[0, n] in idx_drop) and (not edge_index[1, n] in idx_drop)]
        try:
            data.edge_index = torch.tensor(edge_index).transpose_(0, 1)
            data.x = data.x[idx_nondrop]
        except:
            data = data

        return data

    def delete_edge(self, data, aug_ratio):
        """
        only change edge_index, all the other keys unchanged and consistent
        """
        data.cpu()
        node_num, _ = data.x.size()
        _, edge_num = data.edge_index.size()
        permute_num = int(edge_num * aug_ratio)
        edge_index = data.edge_index.numpy()

        idx_delete = np.random.choice(edge_num, (edge_num - permute_num), replace=False)
        data.edge_index = data.edge_index[:, idx_delete]

        return data

class GraphPromptAugment(torch.nn.Module):
    def __init__(self, gnn_type='SAGE',
                 input_dim=None, hidden_dim=None, gnn_layer_num=2):
        super(GraphPromptAugment, self).__init__()
        self.gnn_type=gnn_type

        if self.gnn_type is "SAGE":
            self.gnn = GraphSage(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GAT":
            self.gnn = GAT(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GCN":
            self.gnn = GCN(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GIN":
            self.gnn = GIN(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        else:
            self.gnn = GraphSage(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)

        self.model = GraphPromptAugmentModel(self.gnn)
    
    def load_ckpt(self, load_path=None):
        if load_path is None:
            return
        else:
            self.model.gnn.load_state_dict(torch.load(load_path))
            return
    
    def get_ft_data(self, data, ft_train_nids, ft_test_nids, ft_eval_nids, sample_num=3):
        ft_train_label = data.y[ft_train_nids]
        ft_test_label = data.y[ft_test_nids]
        ft_eval_label = data.y[ft_eval_nids]
        ft_train_subgraph_list = list(NeighborLoader(data=data, num_neighbors=[10,10], batch_size=1, input_nodes=ft_train_nids))
        ft_test_subgraph_list = list(NeighborLoader(data=data, num_neighbors=[10,10], batch_size=1, input_nodes=ft_test_nids))
        ft_eval_subgraph_list = list(NeighborLoader(data=data, num_neighbors=[10,10], batch_size=1, input_nodes=ft_eval_nids))
        ##### 此处补充训练节点采样2-hop子图 和 测试节点2-hop子图 ，其中训练list归类, dataloader处理成pair的形式
        assert len(ft_train_subgraph_list) == len(ft_train_label), "Length of ft_train_subgraph_list and ft_train_label Confict!"
        ft_label_look_up_tabel = defaultdict(list)
        for i in range(len(ft_train_nids)):
            label = int(ft_train_label[i].item())
            subgraph = ft_train_subgraph_list[i]
            ft_label_look_up_tabel[label].append(subgraph)
    
        ft_train_subgraph_pair = []
        for i in range(len(ft_train_nids)):
            label = int(ft_train_label[i].item())
            center_subgraph = ft_train_subgraph_list[i]
            pos_subgraph_candidates = ft_label_look_up_tabel[label]
            pos_subgraph_list = random.sample(pos_subgraph_candidates, sample_num)
            neg_subgraph_list = []
            for _ in range(1000):
                neg_subgraph = random.choice(ft_train_subgraph_list)
                if neg_subgraph in pos_subgraph_candidates:
                    continue
                else:
                    neg_subgraph_list.append(neg_subgraph)
                if len(neg_subgraph_list) >= sample_num:
                    break
            ft_train_subgraph_pair.append((center_subgraph, pos_subgraph_list, neg_subgraph_list))

        return ft_train_subgraph_pair, ft_label_look_up_tabel, ft_train_subgraph_list, ft_test_subgraph_list, ft_eval_subgraph_list, ft_train_label, ft_test_label, ft_eval_label
    
    def test_model(self, ft_label_look_up_tabel, ft_test_subgraph_list, ft_test_label, device=torch.device("cpu")):
        self.model.eval()
        label_cluster_dict = defaultdict(list)
        for label, subgraph_list in ft_label_look_up_tabel.items():
            for subgraph in subgraph_list:
                subgraph = subgraph.to(device)
                label_cluster_dict[label].append(self.model.forward(subgraph))
        
        label_cluster = []
        for label, subgraph_emb_list in label_cluster_dict.items():
            emb_matx = torch.cat(subgraph_emb_list, dim=0)
            label_cluster.append(torch.mean(emb_matx, dim=0, keepdim=True))
        label_cluster = torch.cat(label_cluster, dim=0)

        test_embds = []
        for i in range(len(ft_test_subgraph_list)):
            test_graph = ft_test_subgraph_list[i]
            test_graph = test_graph.to(device)
            test_embds.append(self.model.forward(test_graph))
        test_embds = torch.cat(test_embds, dim=0)

        test_pred = torch.mm(test_embds, label_cluster.transpose(0,1))
        pred_label = torch.argmax(test_pred, dim=1)
        
        pred_label = pred_label.detach().cpu()
        ft_test_label.detach().cpu()

        accuracy_sum = torch.sum(pred_label==ft_test_label)
        accuracy = 1.0*accuracy_sum/len(ft_test_label)
        return accuracy

    def do_finetune(self, data_config, train_config):
        graph = data_config.get("graph", None)
        ft_train_nids = data_config.get("ft_train_nids", [])
        ft_test_nids = data_config.get("ft_test_nids", [])
        ft_eval_nids = data_config.get("ft_eval_nids", [])
        gnn_type = data_config.get("gnn_type", "Sage")
        pt_dataset_name = data_config.get("pt_dataset_name", "CoraFull")
        load_pt_ckpt = data_config.get("load_pt_ckpt", 200)
        batch_size = data_config.get("ft_batch_size", 10)
        aug_num = data_config.get("ft_aug_num", 3)
        aug_type_list = data_config.get("ft_aug_type_list", ["Drop_node", "Mask_feature", "Delete_edge"])
        aug_ratio_list = data_config.get("aug_ratio_list", [0.05, 0.1, 0.15])
        load_pt_ckpt = data_config.get("load_pt_ckpt", 200)

        epochs = train_config.get("epochs", 30)
        lr = train_config.get("lr", 0.0001)
        weight_decay = train_config.get("weight_decay", 0)
        ckpt_epoch = train_config.get("ckpt_epoch", 30)
        test_epoch = train_config.get("test_epoch", 5)
        opt_type = train_config.get("opt_type", "Adam")
        ft_froze = train_config.get("ft_froze", False)
        device = train_config.get("device", None)
        if device is None:
            device = device = torch.device("cpu")

        if ft_train_nids is None:
            print("No ft_train nodes!")
            exit(0)

        if load_pt_ckpt is not None and pt_dataset_name is not None:
            load_ckpt_path = "./pt_ckpt/{}/Graph_CL_{}_{}.pth".format(pt_dataset_name, gnn_type, load_pt_ckpt)
            print("Loading model from: {}".format(load_ckpt_path))
            self.load_ckpt(load_ckpt_path)
            print("Pretrain model load successfully!")
        else:
            load_path = None
            print("Load failed!")
        
        ###############  finetune data prepare
        ft_train_subgraph_pair, ft_label_look_up_tabel, ft_train_subgraph_list, ft_test_subgraph_list, ft_eval_subgraph_list, \
        ft_train_label, ft_test_label, ft_eval_label = self.get_ft_data(graph, ft_train_nids, ft_test_nids, ft_eval_nids)

        print("---- Fine tune data info ---------")
        print(len(ft_train_subgraph_pair))
        print("Train graph list length: {}".format(len(ft_train_subgraph_list)))
        print("Test graph list length: {}".format(len(ft_test_subgraph_list)))
        print("eval graph list length: {}".format(len(ft_eval_subgraph_list)))
        print("Train graph list length: {}".format(len(ft_train_label)))
        print("Test graph list length: {}".format(len(ft_test_label)))
        print("eval graph list length: {}".format(len(ft_eval_label)))
        print("---- Fine tune train data info ---------")
        for key, value in ft_label_look_up_tabel.items():
            print("Label: {}, graph list length is {}".format(key, len(value)))
        train_dataloader = DataLoader(ft_train_subgraph_pair, batch_size=batch_size, shuffle=False, num_workers=1)

        print("*"*20)
        print(len(train_dataloader))
        print(ft_train_subgraph_pair[0])

        if ft_froze:
            for name, param in self.model.gnn.named_parameters():
                param.requires_grad = False

            if opt_type is "Adam":
                opt = optim.Adam(filter(lambda p: p.requires_grad, self.model.parameters()), lr=lr, weight_decay=weight_decay)
            elif opt_type is "SGD":
                opt = optim.Adam(filter(lambda p: p.requires_grad, self.model.parameters()), lr=lr, weight_decay=weight_decay)
            else:
                print("No fine tune optimizer type: {}".format(ft_opt_type))
                exit(0)
        else:
            if opt_type is "Adam":
                opt = optim.Adam(self.model.parameters(), lr=lr, weight_decay=weight_decay)
            elif opt_type is "SGD":
                opt = optim.Adam(self.model.parameters(), lr=lr, weight_decay=weight_decay)
            else:
                print("No fine tune optimizer type: {}".format(ft_opt_type))
                exit(0)
        
        if device == torch.device("cuda"):
            self.model.to(device)

        print("begin trains")
        for epoch in range(1, epochs+1):
            self.model.train()
            train_loss_accum = 0
            total_step = 0
            for step, batch_data in enumerate(ft_train_subgraph_pair):
                center_subgraphs, pos_subgraph_list, neg_subgraph_list = batch_data[0], batch_data[1], batch_data[2]
                center_embeds = self.model.forward_center(center_subgraphs, aug_num, aug_ratio_list, aug_type_list, device=device)
                pos_subgraph_embeds = self.model.forward_context(pos_subgraph_list, device=device)
                neg_subgraph_embeds = self.model.forward_context(neg_subgraph_list, device=device)
                loss = self.model.loss_c(center_embeds, pos_subgraph_embeds, neg_subgraph_embeds, device=device)

                opt.zero_grad()
                loss.backward()
                opt.step()
                train_loss_accum += loss.item()
                total_step += 1
            acc = self.test_model(ft_label_look_up_tabel, ft_test_subgraph_list, ft_test_label, device)
            print("Epoch: {}, avg loss: {}, acc: {}".format(epoch, train_loss_accum*1.0/total_step, acc))
        
        # self.model.eval()
        # label_cluster_dict = defaultdict(list)
        # for label, subgraph_list in ft_label_look_up_tabel.items():
        #     for subgraph in subgraph_list:
        #         subgraph = subgraph.to(device)
        #         label_cluster_dict[label].append(self.model.forward(subgraph))
        
        # label_cluster = []
        # for label, subgraph_emb_list in label_cluster_dict.items():
        #     emb_matx = torch.cat(subgraph_emb_list, dim=0)
        #     label_cluster.append(torch.mean(emb_matx, dim=0, keepdim=True))
        # label_cluster = torch.cat(label_cluster, dim=0)

        # print("-------- begin test! ---------")

        # test_embds = []
        # for i in range(len(ft_test_subgraph_list)):
        #     test_graph = ft_test_subgraph_list[i]
        #     test_graph = test_graph.to(device)
        #     test_embds.append(self.model.forward(test_graph))
        #     if i%50 == 0:
        #         print("Test: {}/{}".format(i, len(ft_test_subgraph_list)))
        # test_embds = torch.cat(test_embds, dim=0)

        # test_pred = torch.mm(test_embds, label_cluster.transpose(0,1))
        # pred_label = torch.argmax(test_pred, dim=1)
        
        # pred_label = pred_label.detach().cpu()
        # ft_test_label.detach().cpu()

        # accuracy_sum = torch.sum(pred_label==ft_test_label)
        # accuracy = 1.0*accuracy_sum/len(ft_test_label)
        # print("accuracy is {}".format(accuracy))





    