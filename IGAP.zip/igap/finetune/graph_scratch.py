import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
from torch_geometric.loader import DataLoader
from torch_geometric.data import Data
from random import shuffle
import random
import torch.nn.functional as F

from models.graphsage import GraphSage
from models.gat import GAT
from models.gin import GIN
from models.gcn import GCN

class GraphScratchModel(torch.nn.Module):
    def __init__(self, gnn, hidden_dim, class_num):
        super(GraphScratchModel, self).__init__()
        self.gnn = gnn
        self.class_num = class_num
        self.head = torch.nn.Sequential(torch.nn.Linear(hidden_dim, hidden_dim),
                                                   torch.nn.ReLU(inplace=True),
                                                   torch.nn.Linear(hidden_dim, class_num))

    def forward(self, data, batch=None, graph_emb=False):
        x = data.x
        edge_index = data.edge_index
        batch = batch
        x = self.gnn(x, edge_index, batch, graph_emb)
        logits = self.head(x)
        return logits

    def loss_cross_entropy(self, logits, labels):
        crossentropyloss = nn.CrossEntropyLoss(reduce="mean")
        loss = crossentropyloss(logits, labels)
        return loss

class GraphScratch(torch.nn.Module):
    def __init__(self,gnn_type='SAGE', input_dim=None, hidden_dim=None, gnn_layer_num=2, num_class=2):
        super(GraphScratch, self).__init__()
        self.gnn_type=gnn_type

        if self.gnn_type is "SAGE":
            self.gnn = GraphSage(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GAT":
            self.gnn = GAT(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GCN":
            self.gnn = GCN(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GIN":
            self.gnn = GIN(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        else:
            print("No GNN model: {}".format(self.gnn_type))

        self.model = GraphScratchModel(self.gnn, hidden_dim, num_class)
    
    def do_finetune(self, data_config, train_config):
        graph = data_config.get("graph", None)
        ft_train_nids = data_config.get("ft_train_nids", None)
        ft_test_nids = data_config.get("ft_test_nids", None)
        ft_eval_nids = data_config.get("ft_eval_nids", None)
        gnn_type = data_config.get("gnn_type", "Sage")
        pt_dataset_name = data_config.get("pt_dataset_name", "CoraFull")
        load_pt_ckpt = data_config.get("load_pt_ckpt", 200)

        epochs = train_config.get("epochs", 30)
        lr = train_config.get("lr", 0.001)
        weight_decay = train_config.get("weight_decay", 0)
        ckpt_epoch = train_config.get("ckpt_epoch", 30)
        opt_type = train_config.get("opt_type", "Adam")
        ft_froze = train_config.get("ft_froze", False)
        device = train_config.get("device", None)
        if device is None:
            device = torch.device("cpu")

        if ft_train_nids is None:
            print("No ft_train nodes!")
            exit(0)
        
        ft_froze = False
        if ft_froze:
            for name, param in self.model.gnn.named_parameters():
                param.requires_grad = False

            if opt_type is "Adam":
                opt = optim.Adam(filter(lambda p: p.requires_grad, self.model.parameters()), lr=lr, weight_decay=weight_decay)
            elif opt_type is "SGD":
                opt = optim.Adam(filter(lambda p: p.requires_grad, self.model.parameters()), lr=lr, weight_decay=weight_decay)
            else:
                print("No fine tune optimizer type: {}".format(ft_opt_type))
                exit(0)
        else:
            if opt_type is "Adam":
                opt = optim.Adam(self.model.parameters(), lr=lr, weight_decay=weight_decay)
            elif opt_type is "SGD":
                opt = optim.Adam(self.model.parameters(), lr=lr, weight_decay=weight_decay)
            else:
                print("No fine tune optimizer type: {}".format(ft_opt_type))
                exit(0)

        ft_train_nids_tensor = torch.tensor(ft_train_nids)
        ft_test_nids_tensor = torch.tensor(ft_test_nids)
        ft_eval_nids_tensor = torch.tensor(ft_eval_nids)
        if device == torch.device("cuda"):
            self.model.to(device)
            graph.to(device)
            ft_train_nids_tensor.to(device)
            ft_test_nids_tensor.to(device)
            ft_eval_nids_tensor.to(device)
        
        self.model.train()
        for i in range(epochs):
            logits = self.model.forward(graph)
            loss = self.model.loss_cross_entropy(logits[ft_train_nids_tensor], graph.y[ft_train_nids_tensor])
            opt.zero_grad()
            loss.backward()
            print(loss.item())
            opt.step()

        print("Fine-tune done!")
        self.model.eval()
        pred_logits = self.model.forward(graph)
        test_logits = pred_logits[ft_test_nids_tensor]
        test_labels = graph.y[ft_test_nids_tensor]

        test_logits.detach().cpu()
        test_labels.detach().cpu()

        pred_logits_softmax = F.softmax(test_logits, dim =1)
        pred_labels = torch.argmax(pred_logits_softmax, dim=1)
        accuracy_sum = torch.sum(pred_labels==test_labels)
        accuracy = 1.0*accuracy_sum/len(test_labels)
        print("accuracy is {}".format(accuracy))