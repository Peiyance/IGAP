import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
from torch_geometric.loader import DataLoader
from torch_geometric.data import Data
from random import shuffle
import random
import torch.nn.functional as F

from models.graphsage import GraphSage
from models.gat import GAT
from models.gin import GIN
from models.gcn import GCN

init = nn.init.xavier_uniform_

class InductiveGraphFinetuneModel(torch.nn.Module):
    def __init__(self, gnn, hidden_dim, class_num, ps_num=32, num_heads=4):
        super(InductiveGraphFinetuneModel, self).__init__()
        self.gnn = gnn
        self.class_num = class_num
        self.ps_num = ps_num
        # self.pt_num = pt_num
        self.Ps = nn.Parameter(torch.Tensor(ps_num, hidden_dim))
        self.Pt = nn.ModuleList()
        for i in range(self.gnn.layer_num):
            self.Pt.append(nn.Linear(hidden_dim, hidden_dim))
        self.Pt_1 = nn.Linear(hidden_dim, hidden_dim)
        self.Pt_2 = nn.Linear(hidden_dim, hidden_dim)
        torch.nn.init.xavier_normal(self.Pt_1.weight, gain=1)
        torch.nn.init.xavier_normal(self.Pt_2.weight, gain=1)

        self.Pl = nn.Parameter(torch.Tensor(class_num, hidden_dim))
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads)
        self.head = torch.nn.Sequential(torch.nn.Linear(hidden_dim, hidden_dim),
                                                   torch.nn.ReLU(inplace=True),
                                                   torch.nn.Linear(hidden_dim, class_num))

    def ps_attn_module(self, feat, mask=None):
        feat, _ = self.attention(feat, self.Ps, self.Ps, key_padding_mask=mask)
        return feat
    
    def forward(self, x, edge_index, batch=None, graph_emb=None):
        in_feat = self.gnn.in_pro_forward(x)
        # feat = self.ps_attn_module(in_feat)
        feat = in_feat
        for i in range(self.gnn.layer_num):
            feat = self.gnn.gnn_layer_forward(feat, edge_index, layer_index=i)
            # feat = self.Pt[i](feat)
            if i == 0:
                feat = self.Pt_1(feat)
            else:
                feat = self.Pt_2(feat)
        return feat
    
    def debug_forward(self, graph, batch=None, graph_emb=False):
        x = graph.x
        edge_index = graph.edge_index
        batch = batch
        feat = self.gnn.in_pro_forward(x)
        for i in range(self.gnn.layer_num):
            feat = self.gnn.gnn_layer_forward(feat, edge_index, i)
        logits = self.head(feat)
        return logits
    
    def calculate_logits(self, graph):
        x, edge_index = graph.x, graph.edge_index
        feat = self.forward(x, edge_index)
        logits = self.head(feat)
        return logits

    def loss_cross_entropy(self, logits, labels):
        crossentropyloss = nn.CrossEntropyLoss(reduce="mean")
        loss = crossentropyloss(logits, labels)
        return loss

class InductiveGraphFineTune(torch.nn.Module):
    def __init__(self,gnn_type='SAGE', input_dim=None, hidden_dim=None, gnn_layer_num=2, num_class=2):
        super(InductiveGraphFineTune, self).__init__()
        self.gnn_type=gnn_type

        if self.gnn_type is "SAGE":
            self.gnn = GraphSage(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GAT":
            self.gnn = GAT(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GCN":
            self.gnn = GCN(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GIN":
            self.gnn = GIN(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        else:
            print("No GNN model: {}".format(self.gnn_type))

        self.model = InductiveGraphFinetuneModel(self.gnn, hidden_dim, num_class)
    
    def load_ckpt(self, load_path):
        self.model.gnn.load_state_dict(torch.load(load_path))
        return
    
    def do_finetune(self, data_config, train_config):
        graph = data_config.get("graph", None)
        ft_train_nids = data_config.get("ft_train_nids", None)
        ft_test_nids = data_config.get("ft_test_nids", None)
        ft_eval_nids = data_config.get("ft_eval_nids", None)
        gnn_type = data_config.get("gnn_type", "Sage")
        pt_dataset_name = data_config.get("pt_dataset_name", "CoraFull")
        load_pt_ckpt = data_config.get("load_pt_ckpt", 200)

        epochs = train_config.get("epochs", 30)
        lr = train_config.get("lr", 0.001)
        weight_decay = train_config.get("weight_decay", 0)
        ckpt_epoch = train_config.get("ckpt_epoch", 30)
        opt_type = train_config.get("opt_type", "Adam")
        ft_froze = train_config.get("ft_froze", False)
        device = train_config.get("device", None)
        if device is None:
            device = torch.device("cpu")

        if ft_train_nids is None:
            print("No ft_train nodes!")
            exit(0)
        
        load_ckpt_path = "./pt_ckpt/{}/Graph_CL_{}_{}.pth".format(pt_dataset_name, gnn_type, load_pt_ckpt)
        print("Loading model from: {}".format(load_ckpt_path))
        # self.load_ckpt(load_ckpt_path)
        print("Pretrain model load successfully!")
        print("Use froze: {}".format(ft_froze))
        print("*"*20)
        if ft_froze:
            for name, param in self.model.gnn.named_parameters():
                param.requires_grad = False

            if opt_type is "Adam":
                opt = optim.Adam(filter(lambda p: p.requires_grad, self.model.parameters()), lr=lr, weight_decay=weight_decay)
            elif opt_type is "SGD":
                opt = optim.Adam(filter(lambda p: p.requires_grad, self.model.parameters()), lr=lr, weight_decay=weight_decay)
            else:
                print("No fine tune optimizer type: {}".format(ft_opt_type))
                exit(0)
        else:
            if opt_type is "Adam":
                opt = optim.Adam(self.model.parameters(), lr=lr, weight_decay=weight_decay)
            elif opt_type is "SGD":
                opt = optim.Adam(self.model.parameters(), lr=lr, weight_decay=weight_decay)
            else:
                print("No fine tune optimizer type: {}".format(ft_opt_type))
                exit(0)

        ft_train_nids_tensor = torch.tensor(ft_train_nids)
        ft_test_nids_tensor = torch.tensor(ft_test_nids)
        ft_eval_nids_tensor = torch.tensor(ft_eval_nids)
        if device == torch.device("cuda"):
            self.model.to(device)
            graph.to(device)
            ft_train_nids_tensor.to(device)
            ft_test_nids_tensor.to(device)
            ft_eval_nids_tensor.to(device)
        
        self.model.train()
        for i in range(epochs):
            logits = self.model.calculate_logits(graph)
            # logits = self.model.debug_forward(graph)
            # print("mark")
            # print(logits.size())
            loss = self.model.loss_cross_entropy(logits[ft_train_nids_tensor], graph.y[ft_train_nids_tensor])
            opt.zero_grad()
            loss.backward()
            print(loss.item())
            opt.step()

        print("Fine-tune done!")
        self.model.eval()
        pred_logits = self.model.calculate_logits(graph)
        test_logits = pred_logits[ft_test_nids_tensor]
        test_labels = graph.y[ft_test_nids_tensor]

        test_logits.detach().cpu()
        test_labels.detach().cpu()

        pred_logits_softmax = F.softmax(test_logits, dim =1)
        pred_labels = torch.argmax(pred_logits_softmax, dim=1)
        accuracy_sum = torch.sum(pred_labels==test_labels)
        accuracy = 1.0*accuracy_sum/len(test_labels)
        print("accuracy is {}".format(accuracy))