import torch
import torch.optim as optim
from torch.autograd import Variable
from torch_geometric.loader import DataLoader
from torch_geometric.data import Data
from random import shuffle
import random

from models.graphsage import GraphSage
from models.gat import GAT
from models.gin import GIN
from models.gcn import GCN
from utils.graph_cl_utils import graph_views


class GraphCLModel(torch.nn.Module):
    def __init__(self, gnn, hidden_dim=16):
        super(GraphCLModel, self).__init__()
        self.gnn = gnn
        self.projection_head = torch.nn.Sequential(torch.nn.Linear(hidden_dim, hidden_dim),
                                                   torch.nn.ReLU(inplace=True),
                                                   torch.nn.Linear(hidden_dim, hidden_dim))

    def forward_cl(self, x, edge_index, batch, graph_emb=True):
        x = self.gnn(x, edge_index, batch, graph_emb)
        x = self.projection_head(x)
        return x

    def loss_cl(self, x1, x2):
        T = 0.1
        batch_size, _ = x1.size()
        x1_abs = x1.norm(dim=1)
        x2_abs = x2.norm(dim=1)
        sim_matrix = torch.einsum('ik,jk->ij', x1, x2) / torch.einsum('i,j->ij', x1_abs, x2_abs)
        sim_matrix = torch.exp(sim_matrix / T)
        pos_sim = sim_matrix[range(batch_size), range(batch_size)]
        loss = pos_sim / ((sim_matrix.sum(dim=1) - pos_sim) + 1e-4)
        loss = - torch.log(loss).mean() + 10
        return loss

class GraphCL(torch.nn.Module):
    def __init__(self, gnn_type='SAGE', input_dim=None, hidden_dim=None, gnn_layer_num=2):
        super(GraphCL, self).__init__()
        self.gnn_type=gnn_type

        if self.gnn_type is "SAGE":
            self.gnn = GraphSage(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GAT":
            self.gnn = GAT(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GCN":
            self.gnn = GCN(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        elif self.gnn_type is "GIN":
            self.gnn = GIN(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)
        else:
            self.gnn = GraphSage(input_dim=input_dim, hidden_dim=hidden_dim, out_dim=hidden_dim, layer_num=gnn_layer_num, pool=None)

        self.model = GraphCLModel(self.gnn, hidden_dim)
    
    def get_loader(self, graph_list, batch_size,
                   aug1=None, aug2=None, aug_ratio=None, pretext="GraphCL"):

        if len(graph_list) % batch_size == 1:
            raise KeyError(
                "batch_size {} makes the last batch only contain 1 graph, \n which will trigger a zero bug in GraphCL!")

        if pretext == 'GraphCL':
            shuffle(graph_list)
            if aug1 is None:
                aug1 = random.sample(['dropN', 'permE', 'maskN'], k=1)
            if aug2 is None:
                aug2 = random.sample(['dropN', 'permE', 'maskN'], k=1)
            if aug_ratio is None:
                aug_ratio = random.randint(1, 3) * 1.0 / 10  # 0.1,0.2,0.3

            print("===graph views: {} and {} with aug_ratio: {}".format(aug1, aug2, aug_ratio))

            view_list_1 = []
            view_list_2 = []
            for g in graph_list:
                view_g = graph_views(data=g, aug=aug1, aug_ratio=aug_ratio)
                view_g = Data(x=view_g.x, edge_index=view_g.edge_index)
                view_list_1.append(view_g)
                view_g = graph_views(data=g, aug=aug2, aug_ratio=aug_ratio)
                view_g = Data(x=view_g.x, edge_index=view_g.edge_index)
                view_list_2.append(view_g)

            loader1 = DataLoader(view_list_1, batch_size=batch_size, shuffle=False,
                                 num_workers=1)  # you must set shuffle=False !
            loader2 = DataLoader(view_list_2, batch_size=batch_size, shuffle=False,
                                 num_workers=1)  # you must set shuffle=False !

            return loader1, loader2
        else:
            raise ValueError("pretext should be GraphCL")

    def do_train(self, data_config, train_config):
        graph_list = data_config.get("graph_list", [])
        batch_size = data_config.get("batch_size", 10)
        aug1 = data_config.get("aug1", None)
        aug2 = data_config.get("aug2", None)
        aug_ratio = data_config.get("aug_ratio", None)
        dataset_name = data_config.get("dataset_name", "CoraFull")
        gnn_type = data_config.get("gnn_type", "Sage")

        epochs = train_config.get("epochs", 200)
        lr = train_config.get("lr", 0.0001)
        weight_decay = train_config.get("weight_decay", 0)
        ckpt_epoch = train_config.get("ckpt_epoch", 50)
        opt_type = train_config.get("opt_type", "Adam")
        device = train_config.get("device", None)
        if device is None:
            device = torch.device("cpu")

        ############ data prepare
        loader1, loader2 = self.get_loader(graph_list, batch_size, aug1, aug2, aug_ratio)

        if opt_type is "Adam":
            opt = optim.Adam(self.model.parameters(), lr=lr, weight_decay=weight_decay)
        elif opt_type is "SGD":
            opt = optim.SGD(self.model.parameters(), lr=lr, weight_decay=weight_decay)
        else:
            opt = optim.Adam(self.model.parameters(), lr=lr, weight_decay=weight_decay)

        if device == torch.device("cuda"):
            self.model.to(device)

        for epoch in range(1, epochs+1):
            self.model.train()
            train_loss_accum = 0
            total_step = 0
            for step, batch in enumerate(zip(loader1, loader2)):
                batch1, batch2 = batch
                opt.zero_grad()
                x1 = self.model.forward_cl(batch1.x.to(device), batch1.edge_index.to(device), batch1.batch.to(device), graph_emb=True)
                x2 = self.model.forward_cl(batch2.x.to(device), batch2.edge_index.to(device), batch2.batch.to(device), graph_emb=True)
                loss = self.model.loss_cl(x1, x2)

                loss.backward()
                opt.step()

                train_loss_accum += float(loss.detach().cpu().item())
                total_step = total_step + 1

            train_loss = train_loss_accum / total_step
            print("***epoch: {}/{} | train_loss: {:.8}".format(epoch, epochs, train_loss))

            if epoch % ckpt_epoch == 0:
                torch.save(self.model.gnn.state_dict(),
                           "./pt_ckpt/{}/Graph_CL_{}_{}.pth".format(dataset_name, gnn_type, str(epoch)))
                print("+++model saved ! In: ./pt_ckpt/{}/Graph_CL_{}_{}.pth".format(dataset_name, gnn_type, str(epoch)))