import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, global_mean_pool
from torch_geometric.data import Batch, Data

class GAT(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim=None, out_dim=None, layer_num=2, pool=None):
        super(GAT, self).__init__()
        if hidden_dim is None:
            hidden_dim = int(0.618 * input_dim)  # "golden cut"
        if out_dim is None:
            out_dim = hidden_dim
        self.layer_num = layer_num
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.out_dim = out_dim
        if layer_num < 2:
            raise ValueError('GNN layer_num should >=2 but you set {}'.format(layer_num))
        elif layer_num == 2:
            self.in_pro = nn.Linear(input_dim, hidden_dim)
            self.conv_layers = torch.nn.ModuleList([GATConv(hidden_dim, hidden_dim), GATConv(hidden_dim, out_dim)])
        else:
            self.in_pro = nn.Linear(input_dim, hidden_dim)
            layers = [GATConv(hidden_dim, hidden_dim)]
            for i in range(layer_num - 2):
                layers.append(GATConv(hidden_dim, hidden_dim))
            layers.append(GATConv(hidden_dim, out_dim))
            self.conv_layers = torch.nn.ModuleList(layers)

        if pool is None:
            self.pool = global_mean_pool
        else:
            self.pool = pool

    def forward(self, x, edge_index, batch=None, graph_emb=False):
        feat = self.in_pro(x)
        for conv in self.conv_layers[0:-1]:
            feat = conv(feat, edge_index)
            feat = act(feat)
            feat = F.dropout(feat, training=self.training)

        node_emb = self.conv_layers[-1](feat, edge_index)
        if graph_emb:
            if batch is not None:
                ret_emb = self.pool(node_emb, batch.long())
            else:
                ret_emb = self.pool(node_emb, None)
        else:
            ret_emb = node_emb
        return ret_emb
    
    def in_pro_forward(self, x):
        return self.in_pro(x)
    
    def gnn_layer_forward(self, feat, edge_index, layer_index=0):
        if layer_index >= len(self.conv_layers):
            ret = feat
        else:
            conv = self.conv_layers[layer_index]
            feat = conv(feat, edge_index)
            feat = act(feat)
            # feat = F.dropout(feat, training=self.training)
            ret = feat
        return ret

def act(x=None, act_type='leakyrelu'):
    if act_type == 'leakyrelu':
        if x is None:
            return torch.nn.LeakyReLU()
        else:
            return F.leaky_relu(x)
    elif act_type == 'tanh':
        if x is None:
            return torch.nn.Tanh()
        else:
            return torch.tanh(x)