import torch
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv, global_mean_pool
from torch_geometric.data import Batch, Data

class GraphSage(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim=None, out_dim=None, layer_num=2, pool=None):
        super(GraphSage, self).__init__()
        if hidden_dim is None:
            hidden_dim = int(0.618 * input_dim)  # "golden cut"
        if out_dim is None:
            out_dim = hidden_dim
        if layer_num < 2:
            raise ValueError('GNN layer_num should >=2 but you set {}'.format(layer_num))
        elif layer_num == 2:
            self.conv_layers = torch.nn.ModuleList([SAGEConv(input_dim, hidden_dim), SAGEConv(hidden_dim, out_dim)])
        else:
            layers = [SAGEConv(input_dim, hidden_dim)]
            for i in range(layer_num - 2):
                layers.append(SAGEConv(hidden_dim, hidden_dim))
            layers.append(SAGEConv(hidden_dim, out_dim))
            self.conv_layers = torch.nn.ModuleList(layers)

        if pool is None:
            self.pool = global_mean_pool
        else:
            self.pool = pool

    def forward(self, x, edge_index, batch=None, graph_emb=False):
        for conv in self.conv_layers[0:-1]:
            x = conv(x, edge_index)
            x = act(x)
            x = F.dropout(x, training=self.training)

        node_emb = self.conv_layers[-1](x, edge_index)
        if graph_emb:
            if batch is not None:
                ret_emb = self.pool(node_emb, batch.long())
            else:
                ret_emb = self.pool(node_emb, None)
        else:
            ret_emb = node_emb
        return ret_emb


def act(x=None, act_type='leakyrelu'):
    if act_type == 'leakyrelu':
        if x is None:
            return torch.nn.LeakyReLU()
        else:
            return F.leaky_relu(x)
    elif act_type == 'tanh':
        if x is None:
            return torch.nn.Tanh()
        else:
            return torch.tanh(x)